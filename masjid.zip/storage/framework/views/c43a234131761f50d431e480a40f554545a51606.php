<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role == 'Admin'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Laporan Data Masjid</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Laporan</li>
                    <li class="breadcrumb-item">Hibah</li>
                </ol>
                <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <!-- notif -->
                <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- end error -->
                
                <div class="card mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Cetak Laporan Filter - Harian - Bulan - Tahun</h6>
                    </div>
                    <div class="card-body">
                        <div class="form-row mt-4">
                            <div class="col-6 col-sm-6">
                                <label>Tanggal Awal </label>
                                <input class=" form-control" min="2022-01-01" name="start" id="start"
                                    type="date" />
                            </div>
                            <div class="col-6 col-sm-6">
                                <label>Tanggal Akhir</label>
                                <input class=" form-control" min="2022-01-01" name="end" id="end"
                                    type="date" />
                            </div>
                        </div>
                        
                        <div class="input-group" style="margin-top: 10px">
                            <a href="#"
                                onclick="this.href='/laporan/masjid/'+document.getElementById('start').value +
                            '/' + document.getElementById('end').value"
                                target="_blank" class="btn btn-primary">Cetak
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\1 perancangan bantuan hibah rumah ibadah pemerintah provinsi jambi\MASJID\resources\views/laporan/index.blade.php ENDPATH**/ ?>