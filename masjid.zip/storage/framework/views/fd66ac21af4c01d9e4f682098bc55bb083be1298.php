<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->role == 'Admin'): ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Detail Masjid</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/data/masjid')); ?>"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a></li>
                <li class="breadcrumb-item active">Data Masjid</li>
            </ol>
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-primary" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>

                <div class="row">

                    <div class="col-4">
                        <!-- Profile picture card-->
                        <div class="card mb-4 mb-0">
                            <div class="card-header">Foto Masjid</div>
                            <div class="card-body text-center">
                                <!-- Profile picture image-->
                                <img class="img-fluid" style="width: 600px; height: auto;" src="<?php echo e(url('/file_foto/'.$det->foto )); ?>" alt="images" />
                                <!-- Profile picture help block-->
                                <div class="small font-italic text-muted mb-4">Klik Foto Untuk Lebih Jelas</div>
                                <!-- Profile picture upload button-->
                            </div>
                        </div>
                    </div>
                    <div class="col-8">
                        <!-- Account details card-->
                        <div class="card mb-4">
                            <div class="card-header">Detail Masjid</div>
                            <div class="card-body">
                                <form>
                                    <!-- Form Group (username)-->
                                    <div class="mb-3">
                                        <label for="inputUsername">Nama Masjid</label>
                                        <input class="form-control" type="text" value="<?php echo e($det->nama); ?>" disabled>
                                    </div>
                                    <!-- Form Group (email address)-->
                                    <div class="mb-3">
                                        <label for="inputEmailAddress">Kab / Kota</label>
                                        <input class="form-control" type="text" value="<?php echo e($det->kabko); ?>" disabled>
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputEmailAddress">Lokasi</label>
                                        <textarea class="form-control" rows="2" disabled><?php echo e($det->lokasi); ?></textarea>
                                    </div>
                                    <!-- Form Row-->
                                    <div class="row gx-3 mb-3">
                                        <!-- Form Group (phone number)-->
                                        <div class="col-md-6">
                                            <label for="inputPhone">Jumlah Pengajuan</label>
                                            <input class="form-control" type="text" value="Rp. <?php echo e(number_format($det->rp)); ?>" disabled>
                                        </div>
                                        <!-- Form Group (birthday)-->
                                        <div class="col-md-6">
                                            <label for="inputBirthday">Jumlah ACC</label>
                                            <input class="form-control" type="text" name="birthday"  value="Rp. <?php echo e(number_format($det->acc)); ?>" disabled>
                                        </div>

                                    </div>
                                    <!-- Form Group (username)-->
                                    <div class="mb-3">
                                        <label for="inputUsername">Status</label>
                                        <input class="form-control" type="text" value="<?php echo e($det->status); ?>" disabled>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>

        </div>
    </main>
<?php endif; ?>
<?php if(auth()->user()->role == '0'): ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Detail Masjid</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/data/masjid/')); ?>"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a></li>
                <li class="breadcrumb-item active">Data Masjid</li>
            </ol>
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-primary" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>

                <div class="row">

                    <div class="col-4">
                        <!-- Profile picture card-->
                        <div class="card mb-4 mb-0">
                            <div class="card-header">Foto Masjid</div>
                            <div class="card-body text-center">
                                <!-- Profile picture image-->
                                <img class="img-fluid" style="width: 600px; height: auto;" src="<?php echo e(url('/file_foto/'.$det->foto )); ?>" alt="images" />
                                <!-- Profile picture help block-->
                                <div class="small font-italic text-muted mb-4">Klik Foto Untuk Lebih Jelas</div>
                                <!-- Profile picture upload button-->
                            </div>
                        </div>
                    </div>
                    <div class="col-8">
                        <!-- Account details card-->
                        <div class="card mb-4">
                            <div class="card-header">Detail Masjid</div>
                            <div class="card-body">
                                <form>
                                    <!-- Form Group (username)-->
                                    <div class="mb-3">
                                        <label for="inputUsername">Nama Masjid</label>
                                        <input class="form-control" type="text" value="<?php echo e($det->nama); ?>" disabled>
                                    </div>
                                    <!-- Form Group (email address)-->
                                    <div class="mb-3">
                                        <label for="inputUsername">Kab / Kota</label>
                                        <input class="form-control" type="text" value="<?php echo e($det->kabko); ?>" disabled>
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputEmailAddress">Lokasi</label>
                                        <textarea class="form-control" rows="2" disabled><?php echo e($det->lokasi); ?></textarea>
                                    </div>
                                    <!-- Form Row-->
                                    <div class="row gx-3 mb-3">
                                        <!-- Form Group (phone number)-->
                                        <div class="col-md-6">
                                            <label for="inputPhone">Jumlah Pengajuan</label>
                                            <input class="form-control" type="text" value="Rp. <?php echo e(number_format($det->rp)); ?>" disabled>
                                        </div>
                                        <!-- Form Group (birthday)-->
                                        <div class="col-md-6">
                                            <label for="inputBirthday">Jumlah ACC</label>
                                            <input class="form-control" type="text" name="birthday"  value="Rp. <?php echo e(number_format($det->acc)); ?>" disabled>
                                        </div>

                                    </div>
                                    <!-- Form Group (username)-->
                                    <div class="mb-3">
                                        <label for="inputUsername">Status</label>
                                        <input class="form-control" type="text" value="<?php echo e($det->status); ?>" disabled>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>

        </div>
    </main>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RAIN\MASJID\resources\views/masjid/detail.blade.php ENDPATH**/ ?>