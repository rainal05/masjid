<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role == 'Admin'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Data Masjid</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"><a href="#" data-toggle="modal" data-target="#exampleModal">
                            Tambah Data</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#" data-toggle="modal" data-target="#exampleModal"> <i
                                class="fa fa-plus-circle" aria-hidden="true"></i></a></li>
                </ol>
                <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <!-- notif -->
                <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- end error -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th width="5%">No</th>
                                        <th>Nama Masjid</th>
                                        <th>Status</th>
                                        <th width="16%">Pilihan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $masjid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->nama ?? 'Admin'); ?></td>
                                            <td><?php echo e($item->status); ?></td>
                                            <td nowrap>
                                                <a href="/data/masjid/detail/<?php echo e($item->id); ?>/"
                                                    class="btn btn-info btn-sm">
                                                    <i class="fa fa-info-circle"></i> Detail
                                                </a>
                                                
                                                <a href="/data/masjid/<?php echo e($item->id); ?>/delete"
                                                    class="btn btn-danger btn-sm"
                                                    onclick="return confirm('Anda yakin ingin menghapus ?')">
                                                    <i class="fa fa-trash" aria-hidden="true"></i> Hapus
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- Modal tambah -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Masjid</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form action="<?php echo e(url('/data/masjid/store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-row">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress">Nama Masjid</label>
                                    <input type="text" name="nama" class="form-control" placeholder="Nama Masjid">
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress">Kabupaten / Kota</label>
                                    <select name="kabko" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                        <option value="Kabupaten Batanghari">Kabupaten Batanghari</option>
                                        <option value="Kabupaten Bungo">Kabupaten Bungo</option>
                                        <option value="Kabupaten Kerinci">Kabupaten Kerinci</option>
                                        <option value="Kabupaten Merangin">Kabupaten Merangin</option>
                                        <option value="Kabupaten Muaro Jambi">Kabupaten Muaro Jambi</option>
                                        <option value="Kabupaten Sarolangun">Kabupaten Sarolangun</option>
                                        <option value="Kabupaten Tanjung Jabung Barat">Kabupaten Tanjung Jabung Barat
                                        </option>
                                        <option value="Kabupaten Tanjung Jabung Timur">Kabupaten Tanjung Jabung Timur
                                        </option>
                                        <option value="Kabupaten Tebo">Kabupaten Tebo</option>
                                        <option value="Kota Jambi">Kota Jambi</option>
                                        <option value="Kota Sungai Penuh">Kota Sungai Penuh</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress">Lokasi Masjid</label>
                                    <textarea class="form-control" placeholder="Lokasi Masjid" name="lokasi" rows="3"></textarea>
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress">Jumlah Pengajuan</label>
                                    <input type="number" min="1" name="rp" class="form-control" placeholder="Rp. xxx">
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress">Foto Masjid</label>
                                    <input type="file" name="foto" class="form-control">
                                </div>
                            </div>
                            <label class="form-label">
                                <span class="badge border-dark border-1 text-dark"><i>Note : Format foto JPG/JPEG/PNG Min :
                                        2 Mb</i></span>
                            </label>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- Modal tambah -->
    <?php endif; ?>
    <?php if(auth()->user()->role == '0'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Belum ACC</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Data Masjid</li>
                    <li class="breadcrumb-item ">Belum ACC</li>
                </ol>
                <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <!-- notif -->
                <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- end error -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th width="5%">No</th>
                                        <th>Nama Masjid</th>
                                        <th width="10%">Detail</th>
                                        <th width="8%">ACC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $blm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->nama ?? 'Admin'); ?></td>
                                            <td>
                                                <a href="/data/masjid/detail/<?php echo e($item->id); ?>/"
                                                    class="btn btn-info btn-sm">
                                                    <i class="fa fa-info-circle"></i> Detail
                                                </a>
                                            </td>
                                            <td nowrap>
                                                <a href="/data/masjid/acc/<?php echo e($item->id); ?>/"
                                                    class="btn btn-success btn-sm">
                                                    <i class="fa fa-info-circle"></i> ACC
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RAIN\MASJID\resources\views/masjid/index.blade.php ENDPATH**/ ?>