<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Form Acc</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Data Masjid</li>
            <li class="breadcrumb-item "><?php echo e($acc->nama); ?></li>
        </ol>
        <!-- notif -->
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-primary" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>
        <!-- notif -->
        <!-- error -->
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        <!-- end error -->
        <div class="card mb-4">
            <div class="card-body">
                <form action="/data/masjid/acc/<?php echo e($acc->id); ?>/update" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-row mt-4">
                        <div class="col-6 col-sm-6">
                            <label for="inputEmailAddress">Jumlah Pengajuan</label>
                            <input type="text" value="<?php echo e($acc->rp); ?>" disabled class="form-control">
                        </div>
                        <div class="col-6 col-sm-6">
                            <label for="inputEmailAddress">Jumlah ACC</label>
                            <input type="number" min="1" name="acc" value="<?php echo e($acc->email); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="form-row mt-4">
                        <div class="col-12 col-sm-12">
                            <label for="inputPassword">Status</label>
                            <select name="status" class="multisteps-form__select form-control">
                                
                                    <option value="ACC">ACC</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                        <input type="submit" class="btn btn-success" value="Update">
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\1 perancangan bantuan hibah rumah ibadah pemerintah provinsi jambi\MASJID\resources\views/acc/acc.blade.php ENDPATH**/ ?>