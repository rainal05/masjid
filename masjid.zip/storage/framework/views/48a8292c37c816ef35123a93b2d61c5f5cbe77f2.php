<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Edit Data Konten</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">
                    <a href="<?php echo e(url('/data/konten', [])); ?>"> <i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a>
                </li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/data/konten', [])); ?>">Data Konten</a></li>
            </ol>
            <div class="card mb-4">
                <div class="card-body">
                    <form action="/data/konten/<?php echo e($masuk->id); ?>/update" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-row mt-4">
                            <div class="col-12 col-sm-12">
                                <label for="inputPassword">Pilih Data Masjid</label>
                                <select name="masjid_id" class="multisteps-form__select form-control">
                                    <option value="">-- PILIH --</option>
                                    <?php $__currentLoopData = $masjid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                            <input type="submit" class="btn btn-success" value="Update">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\1 perancangan bantuan hibah rumah ibadah pemerintah provinsi jambi\MASJID\resources\views/konten/edit.blade.php ENDPATH**/ ?>