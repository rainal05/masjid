<?php $__env->startSection('content'); ?>

<?php if(auth()->user()->role == '0'): ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">ACC</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Data Masjid</li>
            <li class="breadcrumb-item ">ACC</li>
        </ol>
        <!-- notif -->
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-primary" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>
        <!-- notif -->
        <!-- error -->
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        <!-- end error -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Nama Masjid</th>
                                <th width="10%">Detail</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $acc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->nama ??'Admin'); ?></td>
                                    <td>
                                        <a href="/data/masjid/detail/<?php echo e($item->id); ?>/" class="btn btn-info btn-sm">
                                            <i class="fa fa-info-circle"></i> Detail
                                        </a>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RAIN\MASJID\resources\views/acc/index.blade.php ENDPATH**/ ?>